// Sample NFT data
const nfts = [
    {
        id: 1,
        name: "Cosmic Explorer #123",
        price: "2.5 SOL",
        image: "https://images.unsplash.com/photo-1620336655055-bd87c1e80c60?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
        creator: {
            name: "CryptoArtist",
            avatar: "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80"
        },
        description: "A unique digital artwork exploring the cosmos and beyond. This NFT grants access to exclusive content and future airdrops.",
        properties: [
            { trait: "Background", value: "Space" },
            { trait: "Eyes", value: "Laser" },
            { trait: "Rarity", value: "Legendary" }
        ]
    },
    {
        id: 2,
        name: "Digital Dreamscape #45",
        price: "1.8 SOL",
        image: "https://images.unsplash.com/photo-1642784353723-67c75e8ec407?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
        creator: {
            name: "VisionaryArt",
            avatar: "https://images.unsplash.com/photo-1599566150163-29194dcaad36?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80"
        },
        description: "Immerse yourself in this vibrant digital dreamscape. Each element is carefully crafted to create a mesmerizing visual experience.",
        properties: [
            { trait: "Style", value: "Abstract" },
            { trait: "Color", value: "Vibrant" },
            { trait: "Rarity", value: "Rare" }
        ]
    },
    {
        id: 3,
        name: "Neon Samurai #78",
        price: "3.2 SOL",
        image: "https://images.unsplash.com/photo-1636466497217-26a8c3af2913?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
        creator: {
            name: "CyberPunkArt",
            avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80"
        },
        description: "A futuristic samurai warrior bathed in neon lights. This NFT is part of the Cyber Samurai collection with only 100 editions.",
        properties: [
            { trait: "Character", value: "Samurai" },
            { trait: "Theme", value: "Cyberpunk" },
            { trait: "Rarity", value: "Epic" }
        ]
    },
    {
        id: 4,
        name: "Abstract Emotions #12",
        price: "1.5 SOL",
        image: "https://images.unsplash.com/photo-1579546929662-711aa81148cf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
        creator: {
            name: "EmotionArt",
            avatar: "https://images.unsplash.com/photo-1494790108755-2616b612b786?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80"
        },
        description: "An abstract representation of human emotions through color and form. This piece captures the complexity of feelings in a digital format.",
        properties: [
            { trait: "Style", value: "Abstract" },
            { trait: "Emotion", value: "Complex" },
            { trait: "Rarity", value: "Common" }
        ]
    },
    {
        id: 5,
        name: "Crypto Punk #4567",
        price: "4.5 SOL",
        image: "https://images.unsplash.com/photo-1620641788421-7a1c342ea42e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
        creator: {
            name: "PixelMaster",
            avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80"
        },
        description: "A rare pixel art character from the iconic Crypto Punks collection. One of only 10,000 ever created.",
        properties: [
            { trait: "Type", value: "Punk" },
            { trait: "Accessory", value: "Laser Eyes" },
            { trait: "Rarity", value: "Ultra Rare" }
        ]
    },
    {
        id: 6,
        name: "Ocean Guardian #89",
        price: "2.1 SOL",
        image: "https://images.unsplash.com/photo-1578662996442-48f60103fc96?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=800&q=80",
        creator: {
            name: "MarineArt",
            avatar: "https://images.unsplash.com/photo-1580489944761-15a19d654956?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=500&q=80"
        },
        description: "A mystical guardian of the deep oceans, protecting marine life and underwater treasures.",
        properties: [
            { trait: "Environment", value: "Ocean" },
            { trait: "Role", value: "Guardian" },
            { trait: "Rarity", value: "Uncommon" }
        ]
    }
];

// DOM Elements
const nftGrid = document.getElementById('nftGrid');
const nftDetail = document.getElementById('nftDetail');
const backBtn = document.getElementById('backBtn');
const connectWalletBtn = document.getElementById('connectWallet');
const buyBtn = document.getElementById('buyBtn');

// Render NFT grid
function renderNFTGrid() {
    nftGrid.innerHTML = '';
    nfts.forEach(nft => {
        const nftCard = document.createElement('div');
        nftCard.className = 'nft-card';
        nftCard.innerHTML = `
            <img src="${nft.image}" alt="${nft.name}" class="nft-image">
            <div class="nft-info">
                <div class="nft-name">${nft.name}</div>
                <div class="nft-price">${nft.price}</div>
                <div class="nft-creator">
                    <img src="${nft.creator.avatar}" alt="${nft.creator.name}" class="creator-avatar">
                    <span>${nft.creator.name}</span>
                </div>
            </div>
        `;
        nftCard.addEventListener('click', () => showNFTDetail(nft.id));
        nftGrid.appendChild(nftCard);
    });
}

// Show NFT detail
function showNFTDetail(id) {
    const nft = nfts.find(nft => nft.id === id);
    if (nft) {
        document.getElementById('detailImage').src = nft.image;
        document.getElementById('detailName').textContent = nft.name;
        document.getElementById('detailCreatorAvatar').src = nft.creator.avatar;
        document.getElementById('detailCreatorName').textContent = nft.creator.name;
        document.getElementById('detailPrice').textContent = nft.price;
        document.getElementById('detailDescription').textContent = nft.description;
        
        const propertiesContainer = document.getElementById('detailProperties');
        propertiesContainer.innerHTML = '';
        nft.properties.forEach(prop => {
            const propElement = document.createElement('div');
            propElement.className = 'property';
            propElement.innerHTML = `
                <strong>${prop.trait}</strong><br>${prop.value}
            `;
            propertiesContainer.appendChild(propElement);
        });
        
        nftDetail.classList.add('active');
        window.scrollTo(0, 0);
    }
}

// Back button event
backBtn.addEventListener('click', () => {
    nftDetail.classList.remove('active');
});

// Connect wallet simulation
connectWalletBtn.addEventListener('click', () => {
    connectWalletBtn.textContent = 'Connected!';
    connectWalletBtn.style.background = 'var(--secondary)';
    alert('Wallet connected successfully! In a real implementation, this would connect to your Solana wallet.');
});

// Buy button simulation
buyBtn.addEventListener('click', () => {
    const nftName = document.getElementById('detailName').textContent;
    alert(`Purchase initiated for ${nftName}! In a real implementation, this would process the transaction on the Solana blockchain.`);
});

// Initialize
document.addEventListener('DOMContentLoaded', () => {
    renderNFTGrid();
});